from django.apps import AppConfig


class LeonConfig(AppConfig):
    name = 'leon'
