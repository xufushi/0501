from django.apps import AppConfig


class ThveninConfig(AppConfig):
    name = 'thvenin'
